package com.maviniciusdev.back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SceaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SceaApplication.class, args);
    }

}
