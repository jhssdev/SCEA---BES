package com.maviniciusdev.back.appuser;

public enum AppUserRole {
    USER,
    ADMIN
}
