package com.maviniciusdev.back.email;

public interface EmailSender {
    void send(String to, String email);
}
