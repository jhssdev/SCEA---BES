package com.maviniciusdev.back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SceaApplicationTests {

	@Test
	void contextLoads() {
	}

}
